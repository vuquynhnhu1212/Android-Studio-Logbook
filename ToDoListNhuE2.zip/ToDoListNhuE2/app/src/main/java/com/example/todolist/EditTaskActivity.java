package com.example.todolist;

import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class EditTaskActivity extends AppCompatActivity {

    private int taskPosition = -1; // Default to invalid position

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_task);

        // Get the task position from intent
        taskPosition = getIntent().getIntExtra("task_position", -1);

        if (taskPosition == -1 || taskPosition >= MainActivity.taskList.size()) {
            Toast.makeText(this, "Invalid task", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Get the task to edit
        Task taskToEdit = MainActivity.taskList.get(taskPosition);

        // Initialize views
        EditText etTaskName = findViewById(R.id.etTaskNameEdit);
        EditText etDescription = findViewById(R.id.etmDescrptionEdit);
        EditText etDuration = findViewById(R.id.etDurationEdit);
        DatePicker dpDeadline = findViewById(R.id.dpDeadlineEdit);

        // Fill fields with existing task data
        etTaskName.setText(taskToEdit.name);
        etDescription.setText(taskToEdit.description);
        etDuration.setText(String.valueOf(taskToEdit.duration));

        // Set date picker to task's deadline
        Calendar cal = Calendar.getInstance();
        cal.setTime(taskToEdit.deadline);
        dpDeadline.init(
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH),
                null
        );
    }

    public void onClickEditTask(View v) {
        try {
            // Get updated values from views
            String name = ((EditText) findViewById(R.id.etTaskNameEdit)).getText().toString();
            String description = ((EditText) findViewById(R.id.etmDescrptionEdit)).getText().toString();
            int duration = Integer.parseInt(((EditText) findViewById(R.id.etDurationEdit)).getText().toString());

            DatePicker dp = findViewById(R.id.dpDeadlineEdit);
            String dateStr = String.format("%d/%d/%d",
                    dp.getDayOfMonth(),
                    dp.getMonth() + 1,
                    dp.getYear());

            Date deadline = new SimpleDateFormat("dd/MM/yyyy").parse(dateStr);

            // Validate input
            if (name.isEmpty()) {
                Toast.makeText(this, "Task name cannot be empty", Toast.LENGTH_SHORT).show();
                return;
            }

            // Update the task
            Task updatedTask = new Task(name, deadline, duration, description);
            MainActivity.taskList.set(taskPosition, updatedTask);

            Toast.makeText(this, "Task updated", Toast.LENGTH_SHORT).show();
            finish();

        } catch (ParseException e) {
            Toast.makeText(this, "Invalid date format", Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid duration", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error updating task", Toast.LENGTH_SHORT).show();
        }
    }
}