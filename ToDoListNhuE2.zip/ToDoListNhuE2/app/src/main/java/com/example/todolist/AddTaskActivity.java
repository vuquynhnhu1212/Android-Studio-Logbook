package com.example.todolist;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class AddTaskActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        // Initialize DatePicker with current date
        DatePicker dp = findViewById(R.id.dpDeadline);
        Calendar c = Calendar.getInstance();
        dp.init(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH), null);

        // Set up Add button click listener
        Button buttonAdd = findViewById(R.id.buttonAdd);
        buttonAdd.setOnClickListener(v -> saveDetails());
    }

    private void saveDetails() {
        // Get references to all input fields
        EditText tasknameTxt = findViewById(R.id.etTaskName);
        DatePicker datePickerDeadline = findViewById(R.id.dpDeadline);
        EditText durationTxt = findViewById(R.id.etDuration);
        EditText detailsTxt = findViewById(R.id.etmDescription);

        // Get input values
        String taskname = tasknameTxt.getText().toString().trim();
        String durationStr = durationTxt.getText().toString().trim();
        String details = detailsTxt.getText().toString().trim();

        // Validate inputs
        if (taskname.isEmpty()) {
            tasknameTxt.setError("Task name is required");
            tasknameTxt.requestFocus();
            return;
        }

        if (durationStr.isEmpty()) {
            durationTxt.setError("Duration is required");
            durationTxt.requestFocus();
            return;
        }

        // Parse duration
        int duration;
        try {
            duration = Integer.parseInt(durationStr);
            if (duration <= 0) {
                durationTxt.setError("Duration must be positive");
                durationTxt.requestFocus();
                return;
            }
        } catch (NumberFormatException e) {
            durationTxt.setError("Enter a valid number");
            durationTxt.requestFocus();
            return;
        }

        // Format deadline date
        int day = datePickerDeadline.getDayOfMonth();
        int month = datePickerDeadline.getMonth() + 1; // Months are 0-based
        int year = datePickerDeadline.getYear();
        String deadline = String.format("%02d/%02d/%04d", day, month, year);

        try {
            // Create task object
            Date deadlineDate = new SimpleDateFormat("dd/MM/yyyy").parse(deadline);
            Task newTask = new Task(taskname, deadlineDate, duration, details);


            // Add to in-memory list
            MainActivity.taskList.add(newTask);

            // Show success message and finish
            Toast.makeText(this, "Task created successfully!", Toast.LENGTH_SHORT).show();
            finish();

        } catch (ParseException e) {
            Toast.makeText(this, "Error parsing date", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
}