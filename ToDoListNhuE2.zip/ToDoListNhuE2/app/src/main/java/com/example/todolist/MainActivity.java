package com.example.todolist;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static ArrayList<Task> taskList = new ArrayList<>();
    private int taskPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize taskPosition from intent if available
        if (getIntent() != null) {
            taskPosition = getIntent().getIntExtra("task_position", 0);
        }
    }

    public void onClickAdd(View v) {
        Intent i = new Intent(this, AddTaskActivity.class);
        startActivity(i);
    }

    @Override
    protected void onStart() {
        super.onStart();
        ListView lv = findViewById(R.id.listviewTask);
        TaskAdapter adapter = new TaskAdapter(this, taskList);
        lv.setAdapter(adapter);
    }

    public static class TaskAdapter extends ArrayAdapter<Task> {
        public TaskAdapter(Context context, ArrayList<Task> tasks) {
            super(context, 0, tasks);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Task t = getItem(position);
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext())
                        .inflate(R.layout.task_item, parent, false);
            }

            TextView tvTaskName = convertView.findViewById(R.id.tvTaskName);
            TextView tvDeadline = convertView.findViewById(R.id.tvDeadline);
            TextView tvDuration = convertView.findViewById(R.id.tvDuration);
            TextView tvDescription = convertView.findViewById(R.id.tvDescription);
            Button buttonDelete = convertView.findViewById(R.id.buttonDelete);
            Button buttonEdit = convertView.findViewById(R.id.buttonEdit);

            tvTaskName.setText(t.name);
            tvDeadline.setText(t.deadline.toString().substring(0, 10));
            tvDuration.setText(String.valueOf(t.duration));
            tvDescription.setText(t.description);

            // Set up Edit button click listener
            buttonEdit.setOnClickListener(v -> {
                Intent intent = new Intent(getContext(), EditTaskActivity.class);
                intent.putExtra("task_position", position);
                getContext().startActivity(intent);
            });

            // Set up Delete button click listener
            buttonDelete.setOnClickListener(v -> {
                try {
                    MainActivity.taskList.remove(position);
                    notifyDataSetChanged();
                    Toast.makeText(getContext(), "Task deleted", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(getContext(), "Failed to delete task", Toast.LENGTH_SHORT).show();
                }
            });

            return convertView;
        }
    }
}