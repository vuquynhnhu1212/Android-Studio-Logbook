package com.example.todolist;

import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class EditTaskActivity extends AppCompatActivity {

    private int taskPosition = -1; // Default to invalid position
    private Task currentTask;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_task);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Get the task position from intent
        taskPosition = getIntent().getIntExtra("task_position", -1);

        if (taskPosition == -1 || taskPosition >= MainActivity.taskList.size()) {
            Toast.makeText(this, "Invalid task", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Get the task to edit
        currentTask = MainActivity.taskList.get(taskPosition);

        // Initialize views
        EditText etTaskName = findViewById(R.id.etTaskNameEdit);
        EditText etDescription = findViewById(R.id.etmDescrptionEdit);
        EditText etDuration = findViewById(R.id.etDurationEdit);
        DatePicker dpDeadline = findViewById(R.id.dpDeadlineEdit);

        // Fill fields with existing task data
        etTaskName.setText(currentTask.getTaskName());
        etDescription.setText(currentTask.getDescription());
        etDuration.setText(String.valueOf(currentTask.getDuration()));

        // Set date picker to task's deadline
        try {
            Date deadline = new SimpleDateFormat("dd/MM/yyyy").parse(currentTask.getDeadline());
            Calendar cal = Calendar.getInstance();
            cal.setTime(deadline);
            dpDeadline.init(
                    cal.get(Calendar.YEAR),
                    cal.get(Calendar.MONTH),
                    cal.get(Calendar.DAY_OF_MONTH),
                    null
            );
        } catch (ParseException e) {
            Toast.makeText(this, "Error parsing deadline date", Toast.LENGTH_SHORT).show();
        }
    }

    public void onClickEditTask(View v) {
        try {
            // Get updated values from views
            String name = ((EditText) findViewById(R.id.etTaskNameEdit)).getText().toString();
            String description = ((EditText) findViewById(R.id.etmDescrptionEdit)).getText().toString();
            int duration = Integer.parseInt(((EditText) findViewById(R.id.etDurationEdit)).getText().toString());

            DatePicker dp = findViewById(R.id.dpDeadlineEdit);
            String dateStr = String.format("%02d/%02d/%04d",
                    dp.getDayOfMonth(),
                    dp.getMonth() + 1,
                    dp.getYear());

            // Validate input
            if (name.isEmpty()) {
                Toast.makeText(this, "Task name cannot be empty", Toast.LENGTH_SHORT).show();
                return;
            }

            if (duration <= 0) {
                Toast.makeText(this, "Duration must be positive", Toast.LENGTH_SHORT).show();
                return;
            }

            // Update the task object
            currentTask.setTaskName(name);
            currentTask.setDescription(description);
            currentTask.setDuration(duration);
            currentTask.setDeadline(dateStr);

            // Update in database
            int rowsAffected = dbHelper.updateTask(currentTask);

            if (rowsAffected > 0) {
                // Update in memory list
                MainActivity.taskList.set(taskPosition, currentTask);
                Toast.makeText(this, "Task updated successfully", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to update task in database", Toast.LENGTH_SHORT).show();
            }

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid duration", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error updating task: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}