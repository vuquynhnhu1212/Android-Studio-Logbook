package com.example.todolist;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static ArrayList<Task> taskList = new ArrayList<>();
    private DatabaseHelper dbHelper;
    private int taskPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Load tasks from database using combined approach
        loadTasksFromDatabase();

        // Initialize taskPosition from intent if available
        if (getIntent() != null) {
            taskPosition = getIntent().getIntExtra("task_position", 0);
        }
    }

    private void loadTasksFromDatabase() {
        taskList.clear();

        // First get all task IDs using getAllTasks
        Cursor cursor = dbHelper.getAllTasks();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") long taskId = cursor.getLong(cursor.getColumnIndex(DatabaseHelper.COLUMN_ID));

                // Then get full details for each task using getTaskDetails
                Task task = dbHelper.getTaskDetails(taskId);
                if (task != null) {
                    taskList.add(task);
                }
            } while (cursor.moveToNext());
            cursor.close();
        }
    }

    public void onClickAdd(View v) {
        Intent i = new Intent(this, AddTaskActivity.class);
        startActivity(i);
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Refresh and load task list from database
        loadTasksFromDatabase();

        ListView lv = findViewById(R.id.listviewTask);
        TaskAdapter adapter = new TaskAdapter(this, taskList);
        lv.setAdapter(adapter);
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }

    public class TaskAdapter extends ArrayAdapter<Task> {
        public TaskAdapter(Context context, ArrayList<Task> tasks) {
            super(context, 0, tasks);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Task task = getItem(position);
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext())
                        .inflate(R.layout.task_item, parent, false);
            }

            TextView tvTaskName = convertView.findViewById(R.id.tvTaskName);
            TextView tvDeadline = convertView.findViewById(R.id.tvDeadline);
            TextView tvDuration = convertView.findViewById(R.id.tvDuration);
            TextView tvDescription = convertView.findViewById(R.id.tvDescription);
            Button buttonDelete = convertView.findViewById(R.id.buttonDelete);
            Button buttonEdit = convertView.findViewById(R.id.buttonEdit);
            Button buttonComplete = convertView.findViewById(R.id.buttonComplete);

            tvTaskName.setText(task.getTaskName());
            tvDeadline.setText(task.getDeadline());
            tvDuration.setText(String.valueOf(task.getDuration()));
            tvDescription.setText(task.getDescription());

            // Set visual state based on completion status
            if (task.isCompleted()) {
                tvTaskName.setPaintFlags(tvTaskName.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                tvTaskName.setAlpha(0.5f);
                tvDeadline.setAlpha(0.5f);
                tvDuration.setAlpha(0.5f);
                tvDescription.setAlpha(0.5f);
                buttonComplete.setText("Completed");
            } else {
                tvTaskName.setPaintFlags(tvTaskName.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
                tvTaskName.setAlpha(1f);
                tvDeadline.setAlpha(1f);
                tvDuration.setAlpha(1f);
                tvDescription.setAlpha(1f);
                buttonComplete.setText("Complete");
            }

            // Set up Edit button click listener
            buttonEdit.setOnClickListener(v -> {
                Intent intent = new Intent(getContext(), EditTaskActivity.class);
                intent.putExtra("task_position", position);
                intent.putExtra("task_id", task.getId());
                getContext().startActivity(intent);
            });

            // Set up Delete button click listener
            buttonDelete.setOnClickListener(v -> {
                try {
                    // Delete from database first
                    int rowsDeleted = dbHelper.deleteTask(task.getId());

                    if (rowsDeleted > 0) {
                        // Then remove from local list
                        taskList.remove(position);
                        notifyDataSetChanged();
                        Toast.makeText(getContext(), "Task deleted", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getContext(), "Failed to delete task", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(getContext(), "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });

            // Set up Complete button click listener
            buttonComplete.setOnClickListener(v -> {
                // Toggle completion status
                boolean newCompletedState = !task.isCompleted();

                // Update in database using toggleTaskCompletion
                int rowsUpdated = dbHelper.toggleTaskCompletion(task.getId(), newCompletedState);

                if (rowsUpdated > 0) {
                    // Update local task object only after successful DB update
                    task.setCompleted(newCompletedState);

                    // Update UI
                    if (newCompletedState) {
                        tvTaskName.setPaintFlags(tvTaskName.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                        tvTaskName.setAlpha(0.5f);
                        tvDeadline.setAlpha(0.5f);
                        tvDuration.setAlpha(0.5f);
                        tvDescription.setAlpha(0.5f);
                        buttonComplete.setText("Completed");
                    } else {
                        tvTaskName.setPaintFlags(tvTaskName.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
                        tvTaskName.setAlpha(1f);
                        tvDeadline.setAlpha(1f);
                        tvDuration.setAlpha(1f);
                        tvDescription.setAlpha(1f);
                        buttonComplete.setText("Complete");
                    }

                    Toast.makeText(getContext(),
                            "Task marked as " + (newCompletedState ? "completed" : "incomplete"),
                            Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getContext(), "Failed to update task status", Toast.LENGTH_SHORT).show();
                }
            });

            return convertView;
        }
    }
}