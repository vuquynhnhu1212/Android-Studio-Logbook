package com.example.todolist;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class AddTaskActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        // Initialize DatePicker with current date
        DatePicker dp = findViewById(R.id.dpDeadline);
        Calendar c = Calendar.getInstance();
        dp.init(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH), null);

        // Set up Add button click listener
        Button buttonAdd = findViewById(R.id.buttonAdd);
        buttonAdd.setOnClickListener(v -> saveDetails());
    }

    private void saveDetails() {
        // Get references to all input fields
        EditText taskNameEditText = findViewById(R.id.etTaskName);
        DatePicker datePickerDeadline = findViewById(R.id.dpDeadline);
        EditText durationEditText = findViewById(R.id.etDuration);
        EditText descriptionEditText = findViewById(R.id.etmDescription);

        // Get input values
        String taskName = taskNameEditText.getText().toString().trim();
        String durationStr = durationEditText.getText().toString().trim();
        String description = descriptionEditText.getText().toString().trim();

        // Validate inputs
        if (taskName.isEmpty()) {
            taskNameEditText.setError("Task name is required");
            taskNameEditText.requestFocus();
            return;
        }

        if (durationStr.isEmpty()) {
            durationEditText.setError("Duration is required");
            durationEditText.requestFocus();
            return;
        }

        // Parse duration
        int duration;
        try {
            duration = Integer.parseInt(durationStr);
            if (duration <= 0) {
                durationEditText.setError("Duration must be positive");
                durationEditText.requestFocus();
                return;
            }
        } catch (NumberFormatException e) {
            durationEditText.setError("Enter a valid number");
            durationEditText.requestFocus();
            return;
        }

        // Format deadline date
        int day = datePickerDeadline.getDayOfMonth();
        int month = datePickerDeadline.getMonth() + 1; // Months are 0-based
        int year = datePickerDeadline.getYear();
        String deadlineStr = String.format("%02d/%02d/%04d", day, month, year);

        try {
            // Parse the deadline string to Date
            Date deadline = new SimpleDateFormat("dd/MM/yyyy").parse(deadlineStr);

            // Create task object
            Task newTask = new Task();
            newTask.setTaskName(taskName);
            newTask.setDeadline(deadlineStr); // Store as string in DB
            newTask.setDuration(duration);
            newTask.setDescription(description);
            newTask.setCompleted(false); // New tasks are not completed by default

            // Save to database
            DatabaseHelper dbHelper = new DatabaseHelper(this);
            long taskId = dbHelper.insertTask(
                    newTask.getTaskName(),
                    newTask.getDeadline(),
                    newTask.getDuration(),
                    newTask.getDescription(),
                    newTask.isCompleted()
            );

            if (taskId != -1) {
                // Set the ID returned from database
                newTask.setId(taskId);

                // Add to in-memory list
                MainActivity.taskList.add(newTask);

                // Show success message and finish
                Toast.makeText(this, "Task created successfully!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to create task", Toast.LENGTH_SHORT).show();
            }

        } catch (ParseException e) {
            Toast.makeText(this, "Error parsing date", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
}