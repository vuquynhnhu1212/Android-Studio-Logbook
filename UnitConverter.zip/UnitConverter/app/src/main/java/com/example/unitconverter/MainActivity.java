package com.example.unitconverter;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    EditText etConvertedValue, ed1;
    Spinner sp2, sp3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unit_converter);
        sp2 = findViewById(R.id.spinner2);
        sp3 = findViewById(R.id.spinner3);
        etConvertedValue = findViewById(R.id.etValue2);
        ed1 = findViewById(R.id.etValue1);
    }
    public void onConvertClick (View v) {
        String choice2 = sp2.getSelectedItem().toString();
        String choice3 = sp3.getSelectedItem().toString();

//TODO: check if text value is valid
double value1 = Double.parseDouble(ed1.getText().toString());
double value2 = 0;

switch (choice2) {
    case "Meter":
        switch (choice3) {
            case "Meter":
                value2 = value1;
                break;
            case "Millimeter":
                value2 = value1*1000;
                break;
            case "Mile":
                value2 = value1*0.000621371192;
                break;
            case "Foot":
                value2 = value1*3.2808399;
                break;
        }
        break;
    case "Millimeter":
        switch (choice3) {
            case "Meter":
                value2 = value1/1000;
                break;
            case "Millimeter":
                value2 = value1;
                break;
            case "Mile":
                value2 = value1*6.213711922e-7;
                break;
            case "Foot":
                value2 = value1*0.0032808399;
                break;
        }
        break;
    case "Mile":
        switch (choice3) {
            case "Meter":
                value2 = value1* 1609.344;
                break;
            case "Millimeter":
                value2 = value1 * 1609344;
                break;
            case "Mile":
                value2 = value1;
                break;
            case "Foot":
                value2 = value1*5280;
                break;
        }
        break;
    case "Foot":
        switch (choice3) {
            case "Meter":
                value2 = value1* 0.3048;
                break;
            case "Millimeter":
                value2 = value1 * 304.8;
                break;
            case "Mile":
                value2 = value1 * 0.0001893939;
                break;
            case "Foot":
                value2 = value1;
                break;
        }
        break;
}
        // Display the converted value
        etConvertedValue.setText(String.valueOf(value2));
    }
     
}